from setuptools import setup

setup(name='evg',
      version='1.1',
      # url='https://github.com/the-gigi/pathology',
      license='MIT',
      author='Nikita Belan',
      author_email='nikitabelan9@gmail.com',
      description='Удобный иструмент для локализации кода Discord ботов',
      zip_safe=False)
